package consumer.Review.controller;

import consumer.Review.model.Model;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;


import javax.swing.*;
import java.io.IOException;


public class ReviewController {

    public int Star;
    @FXML
    TextArea txtReview;
    Button HideView;
    Button OneStar,TwoStar,ThreeStar,FourStar,FiveStar;

    public void SubmitReview (ActionEvent actionEvent) throws IOException {

        Model mod = new Model();

        mod.setReview(txtReview.getText());
        mod.setStar(Star);
        mod.addToDatabase();



        //button "Submit", when clicked changes the view to Thanks.fxml

        //HideView.getScene().getWindow().hide();

        Stage SignUp = new Stage();
        Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getResource("/consumer/Review/view/Thanks.fxml"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        Scene scene = new Scene(root);
        SignUp.setScene(scene);
        SignUp.show();
        SignUp.setResizable(false);
        EmailVer.email();

    }

    public void OneStar (ActionEvent actionEvent) throws IOException
    {
        Star = 1;

    }
    public void TwoStar (ActionEvent actionEvent) throws IOException
    {
        Star = 2;

    }
    public void ThreeStar (ActionEvent actionEvent) throws IOException
    {
        Star = 3;

    }
    public void FourStar (ActionEvent actionEvent) throws IOException
    {
        Star = 4;

    }
    public void FiveStar (ActionEvent actionEvent) throws IOException
    {
        Star = 5;

    }


    public void AdminLogin(ActionEvent actionEvent) throws IOException {

        Stage UserLogin = new Stage();
        Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getResource("/consumer/Review/view/UserLogin.fxml"));
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        Scene scene = new Scene(root);
        UserLogin.setScene(scene);
        UserLogin.show();
        UserLogin.setResizable(false);

    }
}