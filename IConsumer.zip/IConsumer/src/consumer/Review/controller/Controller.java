package consumer.Review.controller;

import consumer.Review.model.Model;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;

public class Controller {

    @FXML
    TextArea txtReview;

    public void SubmitReview(ActionEvent actionEvent) {

        Model mod = new Model();

        mod.setReview(txtReview.getText());
        mod.addToDatabase();

    }
}
