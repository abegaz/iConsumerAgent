package csci33_sentiment_analysis;


import java.util.*;

public class Main {

	public static void main(String[] args) {
	 
	 Scanner scan = new Scanner(System.in);
	 String input = new String();
	 
	 System.out.println("Please enter a sentence, or sentences, to be analyzed.");
	    input += scan.nextLine();
	    scan.close();


     Sentiment_Module sentimentAnalyzer = new Sentiment_Module();
     sentimentAnalyzer.start();

     CalculateSentiment sentimentResult = sentimentAnalyzer.getSentimentResult(input);

   
     System.out.println("According to our analysis your review was rated: " + sentimentResult.getSentimentType());
     System.out.println("");
     System.out.println("Wonder how we came to our conclusion? Below you will find the rating breakdown of your review");
     System.out.println("");

     System.out.println("Sentiments Analysis Breakdown:");
     System.out.println("Very positive: " + sentimentResult.getSentimentClass().getVeryPositive()+"%");
     System.out.println("Positive: " + sentimentResult.getSentimentClass().getSomewhatPositive()+"%");
     System.out.println("Neutral: " + sentimentResult.getSentimentClass().getNeutral()+"%");
     System.out.println("Negative: " + sentimentResult.getSentimentClass().getSomewhatNegative()+"%");
     System.out.println("Very negative: " + sentimentResult.getSentimentClass().getVeryNegative()+"%");


	}

}
