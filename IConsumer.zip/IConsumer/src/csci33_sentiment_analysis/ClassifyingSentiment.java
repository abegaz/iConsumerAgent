package csci33_sentiment_analysis;

public class ClassifyingSentiment {
	 int veryPositive;
	 int somewhatPositive;
	 int neutral;
	 int somewhatNegative;
	 int veryNegative;

	 public int getVeryPositive() {
	  return veryPositive;
	 }

	 public void setVeryPositive(int veryPositive) {
	  this.veryPositive = veryPositive;
	 }

	 public int getSomewhatPositive() {
	  return somewhatPositive;
	 }

	 public void setSomewhatPositive(int somewhatPositive) {
	  this.somewhatPositive = somewhatPositive;
	 }

	 public int getNeutral() {
	  return neutral;
	 }

	 public void setNeutral(int neutral) {
	  this.neutral = neutral;
	 }

	 public int getSomewhatNegative() {
	  return somewhatNegative;
	 }

	 public void setSomewhatNegative(int somewhatNegative) {
	  this.somewhatNegative = somewhatNegative;
	 }

	 public int getVeryNegative() {
	  return veryNegative;
	 }

	 public void setVeryNegative(int veryNegative) {
	  this.veryNegative = veryNegative;
	 }

	}


