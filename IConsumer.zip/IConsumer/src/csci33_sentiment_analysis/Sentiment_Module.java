package csci33_sentiment_analysis;

import java.util.*;


import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import edu.stanford.nlp.ling.CoreAnnotations;
import edu.stanford.nlp.neural.rnn.RNNCoreAnnotations;
import edu.stanford.nlp.pipeline.Annotation;
import edu.stanford.nlp.sentiment.SentimentCoreAnnotations;
import edu.stanford.nlp.sentiment.SentimentCoreAnnotations.SentimentAnnotatedTree;
import edu.stanford.nlp.trees.Tree;
import edu.stanford.nlp.util.CoreMap;



public class Sentiment_Module {
	
		StanfordCoreNLP module;
		
		public void start() {

			  Properties core = new Properties();

			  core.setProperty("annotators", "tokenize, ssplit, parse, sentiment");

			  module = new StanfordCoreNLP(core);
			 }
		
		public CalculateSentiment getSentimentResult(String input) {

			  ClassifyingSentiment classifier = new ClassifyingSentiment();

			  CalculateSentiment result = new CalculateSentiment();

			  if (input != null && input.length() > 0) {

			   Annotation annotation = module.process(input);

			   for(CoreMap sentence: annotation.get(CoreAnnotations.SentencesAnnotation.class)) {

			   Tree tree = sentence.get(SentimentCoreAnnotations.SentimentAnnotatedTree.class);

			   SimpleMatrix simpleMatrix = RNNCoreAnnotations.getPredictions(tree);

			   classifier.setVeryNegative((int)Math.round(simpleMatrix.get(0)*100d));
			   
			   classifier.setSomewhatNegative((int)Math.round(simpleMatrix.get(1)*100d));
			   
			   classifier.setNeutral((int)Math.round(simpleMatrix.get(2)*100d));
			   
			   classifier.setSomewhatPositive((int)Math.round(simpleMatrix.get(3)*100d));
			   
			   classifier.setVeryPositive((int)Math.round(simpleMatrix.get(4)*100d));

			   String setimentType = sentence.get(SentimentCoreAnnotations.SentimentClass.class);

			   result.setSentimentType(setimentType);

			   result.setSentimentClass(classifier);

			   result.setSentimentScore(RNNCoreAnnotations.getPredictedClass(tree));

			   }

			  }
			  return result;
		}
}
