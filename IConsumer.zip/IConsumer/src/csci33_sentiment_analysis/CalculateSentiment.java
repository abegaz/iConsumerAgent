package csci33_sentiment_analysis;

public class CalculateSentiment {
	 String sentimentType;

	 int sentimentScore;

	 ClassifyingSentiment sentimentClass;

	 public String getSentimentType() {
	  return sentimentType;
	 }

	 public void setSentimentType(String sentimentType) {
	  this.sentimentType = sentimentType;
	 }

	 public int getSentimentScore() {
	  return sentimentScore;
	 }

	 public void setSentimentScore(int sentimentScore) {
	  this.sentimentScore = sentimentScore;
	 }

	 public ClassifyingSentiment getSentimentClass() {
	  return sentimentClass;
	 }

	 public void setSentimentClass(ClassifyingSentiment sentimentClass) {
	  this.sentimentClass = sentimentClass;
	 }

}
