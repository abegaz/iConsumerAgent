package csci33_sentiment_analysis.model.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;

public class Model {

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }

    String review;



    public int addToDatabase() {
        int affectedRow=0;
        String query = "insert into Reviews" + " (Review)"
                + " VALUES(?)";

        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement sqlStatement = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);) {
            sqlStatement.setString(1, getReview());



            // get the number of return rows
            affectedRow = sqlStatement.executeUpdate();

        } catch (Exception e) {
            System.out.println("Status: operation failed due to " + e);

        }
        return affectedRow;

    }
}
