package csci33_sentiment_analysis.Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.*;

import org.ejml.simple.SimpleMatrix;

import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import edu.stanford.nlp.ling.CoreAnnotations;
import edu.stanford.nlp.neural.rnn.RNNCoreAnnotations;
import edu.stanford.nlp.pipeline.Annotation;
import edu.stanford.nlp.sentiment.SentimentCoreAnnotations;
import edu.stanford.nlp.sentiment.SentimentCoreAnnotations.SentimentAnnotatedTree;
import edu.stanford.nlp.trees.Tree;
import edu.stanford.nlp.util.CoreMap;
import csci33_sentiment_analysis.model.model.DatabaseConfig;


public class Sentiment_Module {

	StanfordCoreNLP module;
	int vPos;
	int sPos;
	int neu;
	int sNeg;
	int vNeg;

	public void start() {

		Properties core = new Properties();

		core.setProperty("annotators", "tokenize, ssplit, parse, sentiment");

		module = new StanfordCoreNLP(core);
	}

	public CalculateSentiment getSentimentResult(String input) {

		ClassifyingSentiment classifier = new ClassifyingSentiment();

		CalculateSentiment result = new CalculateSentiment();

		if (input != null && input.length() > 0) {

			Annotation annotation = module.process(input);

			for(CoreMap sentence: annotation.get(CoreAnnotations.SentencesAnnotation.class)) {

				Tree tree = sentence.get(SentimentCoreAnnotations.SentimentAnnotatedTree.class);;

				SimpleMatrix simpleMatrix = RNNCoreAnnotations.getPredictions(tree);

				classifier.setVeryNegative((int)Math.round(simpleMatrix.get(0)*100d));

				classifier.setSomewhatNegative((int)Math.round(simpleMatrix.get(1)*100d));

				classifier.setNeutral((int)Math.round(simpleMatrix.get(2)*100d));

				classifier.setSomewhatPositive((int)Math.round(simpleMatrix.get(3)*100d));

				classifier.setVeryPositive((int)Math.round(simpleMatrix.get(4)*100d));

				String setimentType = sentence.get(SentimentCoreAnnotations.SentimentClass.class);

				result.setSentimentType(setimentType);

				result.setSentimentClass(classifier);

				result.setSentimentScore(RNNCoreAnnotations.getPredictedClass(tree));

			}

		}
		return result;
	}
	public int saveReviewIntoDatabase(String review, int stars) {
		int affectedRow=0;
		String query = "insert into reviews" + "(reviews, stars)"
				+ "values(?,?)";

		try (Connection conn = DatabaseConfig.getConnection();
			 PreparedStatement sqlStatement = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);) {
			sqlStatement.setString(1, review);
			sqlStatement.setInt(2, stars);

			// get the number of return rows
			affectedRow = sqlStatement.executeUpdate();

		} catch (Exception e) {
			System.out.println("Status: operation failed due to " + e);

		}
		return affectedRow;

	}
	public int saveReviewIntoDatabase(String review, int vPos, int sPos, int neu, int sNeg, int vNeg) {
		int affectedRow=0;
		String query = "insert into admin" + "(review, vPos, sPos, neu, sNeg, vNeg)"
				+ "values(?,?,?,?,?,?)";

		try (Connection conn = DatabaseConfig.getConnection();
			 PreparedStatement sqlStatement = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);) {
			sqlStatement.setString(1, review);
			sqlStatement.setInt(2, vPos);
			sqlStatement.setInt(3, sPos);
			sqlStatement.setInt(4, neu);
			sqlStatement.setInt(5, sNeg);
			sqlStatement.setInt(6, vNeg);

			// get the number of return rows
			affectedRow = sqlStatement.executeUpdate();

		} catch (Exception e) {
			System.out.println("Status: operation failed due to " + e);

		}
		return affectedRow;

	}
	public void startButton() {
		Scanner scan = new Scanner(System.in);
		String input = new String();

		System.out.println("Please enter a sentence, or sentences, to be analyzed.");
		input += scan.nextLine();
		scan.close();



		Sentiment_Module sentimentAnalyzer = new Sentiment_Module();
		sentimentAnalyzer.start();

		CalculateSentiment sentimentResult = sentimentAnalyzer.getSentimentResult(input);

		vPos = sentimentResult.getSentimentClass().getVeryPositive();
		sPos = sentimentResult.getSentimentClass().getSomewhatPositive();
		neu = sentimentResult.getSentimentClass().getNeutral();
		sNeg = sentimentResult.getSentimentClass().getSomewhatNegative();
		vNeg = sentimentResult.getSentimentClass().getVeryNegative();
	}
}