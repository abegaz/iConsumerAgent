package csci33_sentiment_analysis;


import csci33_sentiment_analysis.Controller.CalculateSentiment;
import csci33_sentiment_analysis.Controller.Sentiment_Module;
import csci33_sentiment_analysis.model.model.DatabaseConfig;

import java.sql.*;
import java.util.*;

public class Main {

    static ArrayList<String[]> result = new ArrayList<String[]>();

    public static void main(String[] args) throws SQLException {


        String reviews = null;
        String query0 = "TRUNCATE TABLE admin";
        String query1 = "select review from reviews where id";

        try (Connection conn = DatabaseConfig.getConnection();

             PreparedStatement sqlStatement1 = conn.prepareStatement(query1, Statement.RETURN_GENERATED_KEYS)) {
            //review = String.valueOf(sqlStatement1.execute());
            PreparedStatement sqlStatement2 = conn.prepareStatement(query0, Statement.CLOSE_ALL_RESULTS);
                sqlStatement2.execute();

            ResultSet rs = sqlStatement1.executeQuery();
            int columnCount = rs.getMetaData().getColumnCount();
            while (rs.next()) {
                String[] row = new String[columnCount];
                for (int i = 0; i < columnCount; i++) {
                    row[i] = rs.getString(i + 1);
                }
                result.add(row);
            }
        } catch (Exception e) {
            System.out.println("Status: operation failed due to " + e);
        }
        for (int i = 0; i < result.size(); i++) {
            reviews = Arrays.toString(result.get(i));
            System.out.print("test " + reviews);


            Sentiment_Module sentimentAnalyzer = new Sentiment_Module();
            sentimentAnalyzer.start();

            CalculateSentiment sentimentResult = sentimentAnalyzer.getSentimentResult(reviews);


            System.out.println("According to our analysis your review was rated: " + sentimentResult.getSentimentType());
            System.out.println("");
            System.out.println("Wonder how we came to our conclusion? Below +you will find the rating breakdown of your review");
            System.out.println("");

            System.out.println("Sentiments Analysis Breakdown for " + reviews + ":");
            System.out.println("Very positive: " + sentimentResult.getSentimentClass().getVeryPositive() + "%");
            System.out.println("Positive: " + sentimentResult.getSentimentClass().getSomewhatPositive() + "%");
            System.out.println("Neutral: " + sentimentResult.getSentimentClass().getNeutral() + "%");
            System.out.println("Negative: " + sentimentResult.getSentimentClass().getSomewhatNegative() + "%");
            System.out.println("Very negative: " + sentimentResult.getSentimentClass().getVeryNegative() + "%");

            String query = "insert into admin" + " (review, very_positive, somewhat_positive, neutral, somewhat_negative, very_negative)"
                    + " VALUES(?,?,?,?,?,?)";

            try {
                try (Connection conn = DatabaseConfig.getConnection();
                     PreparedStatement sqlStatement = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
                    sqlStatement.setString(1, reviews);
                    sqlStatement.setInt(2, sentimentResult.getSentimentClass().getVeryPositive());
                    sqlStatement.setInt(3, sentimentResult.getSentimentClass().getSomewhatPositive());
                    sqlStatement.setInt(4, sentimentResult.getSentimentClass().getNeutral());
                    sqlStatement.setInt(5, sentimentResult.getSentimentClass().getSomewhatNegative());
                    sqlStatement.setInt(6, sentimentResult.getSentimentClass().getVeryNegative());


                    // get the number of return rows
                    sqlStatement.executeUpdate();
                }

            } catch (Exception e) {
                System.out.println("Status: operation failed due to " + e);

            }


        }
    }
}
