package com.review.controller;


import com.review.model.DatabaseConfig;
import com.review.model.Review;
import javafx.animation.PauseTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;

import javax.mail.Session;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.*;
import javafx.application.Application;


public class SignUpController implements Initializable {

    @FXML
    TextField txtUser, txtEmail;
    @FXML
    PasswordField txtPass;
    @FXML
    Button SignUp, login;
    @FXML
    ImageView progress;


    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {

        progress.setVisible(false);

    }

    //connects controller to the model
    @FXML
    public void SignUpUser(ActionEvent actionEvent) {

        progress.setVisible(true);

        Review newData = new Review();

        newData.setUsername(txtUser.getText());
        newData.setPassword(txtPass.getText());
        newData.setEmail(txtEmail.getText());
        newData.addSubribtionToDatabase();

        PauseTransition pt = new PauseTransition();
        pt.setDuration(Duration.seconds(3));
        pt.setOnFinished(ev -> {

        });
        pt.play();

    }

    public void LoginUser(ActionEvent actionEvent) throws SQLException, IOException {


        //Pulls from the database to login user
        Connection conn = DatabaseConfig.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;

        String userEmail = txtEmail.getText();

        String sql = "SELECT * From userinfo WHERE email = ?";
        try {
            ps = conn.prepareStatement(sql);
            ps.setString(1, userEmail);
            rs = ps.executeQuery();

            if (rs.next()) {
                final String username = "IConsumerAgentCSCI3300@gmail.com";
                final String passwordE = "FreezeDriedLiquorMonkeys";

                Properties props = new Properties();
                props.put("mail.smtp.auth", "true");
                props.put("mail.smtp.starttls.enable", "true");
                props.put("mail.smtp.host", "smtp.gmail.com");
                props.put("mail.smtp.port", "587");

                Session session = Session.getInstance(props,
                        new javax.mail.Authenticator() {
                            protected javax.mail.PasswordAuthentication getPasswordAuthentication() {
                                return new PasswordAuthentication(username, passwordE);
                            }
                        });

                try {

                    Message message = new MimeMessage(session);
                    message.setFrom(new InternetAddress("IConsumerAgentCSCI3300@gmail.com"));
                    message.setRecipients(Message.RecipientType.TO,
                            InternetAddress.parse("AlexKirby7@gmail.com"));
                    message.setSubject("Email Test");
                    message.setText("Dear tester,"
                            + "\n\n Testing!!!!!");

                    Transport.send(message);

                    System.out.println("Done");

                } catch (MessagingException e) {
                    throw new RuntimeException(e);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void UserLogin(ActionEvent actionEvent) {

        SignUp.getScene().getWindow().hide();

        Stage SignUp = new Stage();
        Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getResource("/Com/Review/view/UserLogin.fxml"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        Scene scene = new Scene(root);
        SignUp.setScene(scene);
        SignUp.show();
        SignUp.setResizable(false);
        
        
        

    }
        
}
